from modules import oled_display, button_input, config_loader, uds_client

from modules.report_generator import ReportGenerator
import RPi.GPIO as GPIO
import time
import logging
import os

# Load config
config = config_loader.load_config("config.json")

oled = oled_display.OLEDDisplay(config["display"])
buttons = button_input.ButtonInput(list(config["gpio"]["buttons"].values()))
uds = uds_client.UDSClient(config)
report = ReportGenerator(config["report"]["filename"])

BTN_FIRST, BTN_SECOND, BTN_ENTER, BTN_THANKS = list(config["gpio"]["buttons"].values())
menu_combinations = config["menu_combinations"]

def show_text(text):
    oled.clear()
    oled.display_text(text)

# Welcome
show_text("   Welcome to\n  Diagnostics")
time.sleep(2)

# Menu loop
selected_sequence = []
variable = 0
while True:
    show_text("Select Option:\n1.ECU Info\n2.Testcases\n3.Flash\n4.USB\n5.Reserved")
    while True:
        if GPIO.input(BTN_FIRST) == GPIO.LOW:
            variable = (variable * 10) + 1
            selected_sequence.append(BTN_FIRST)
            show_text(str(variable))

        if GPIO.input(BTN_SECOND) == GPIO.LOW:
            variable = (variable * 10) + 2
            selected_sequence.append(BTN_SECOND)
            show_text(str(variable))

        if GPIO.input(BTN_ENTER) == GPIO.LOW:
            key = str(tuple(selected_sequence))
            selected_option = menu_combinations.get(key, "Invalid Input")
            show_text(f"{selected_option}")
            time.sleep(0.5)

            if selected_option == "ECU Information":
                show_text("Fetching ECU Info...")
                uds.get_ecu_information(oled)
                show_text("Done")
                time.sleep(2)

            elif selected_option == "Testcase Execution":
                show_text("Running Testcases...")
                uds.run_testcase(oled)
                show_text("Done")
                time.sleep(2)

            elif selected_option.startswith("File Transfer"):
                show_text("Transferring logs...")
                transfer_files_to_usb()
                show_text("Done")
                time.sleep(2)

            elif selected_option == "Exit":
                show_text("Exiting...")
                time.sleep(1)
                os.system("exit")

            selected_sequence.clear()
            variable = 0

        if GPIO.input(BTN_THANKS) == GPIO.LOW:
            show_text("Shutting Down")
            time.sleep(1)
            os.system("sudo poweroff")

        time.sleep(0.1)
